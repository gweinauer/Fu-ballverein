CREATE TABLE Mannschaft (
 bezeichnung VARCHAR(50) NOT NULL,
 klasse VARCHAR(50) NOT NULL,
 naechstes_spiel DATE NOT NULL,
 cheftrainer SERIAL NOT NULL UNIQUE,
 assistenztrainer SERIAL NOT NULL UNIQUE,
 kapitaen SERIAL NOT NULL UNIQUE
);
ALTER TABLE Mannschaft ADD CONSTRAINT PK_Mannschaft PRIMARY KEY (bezeichnung);


CREATE TABLE Person (
 persnr SERIAL CHECK (persnr < 100000) NOT NULL,
 vname VARCHAR(30) NOT NULL,
 nname VARCHAR(30) NOT NULL,
 gebdat DATE NOT NULL,
 geschlecht CHAR(1) CHECK(geschlecht ='M' OR geschlecht ='W' OR geschlecht ='N') NOT NULL
);
ALTER TABLE Person ADD CONSTRAINT PK_Person PRIMARY KEY (persnr);
ALTER SEQUENCE Person_persnr_seq RESTART WITH 10000 INCREMENT BY 2; 


CREATE TABLE Spiel (
 datum DATE NOT NULL,
 bezeichnung VARCHAR(50) NOT NULL,
 gegner VARCHAR(50) NOT NULL,
 ergebnis VARCHAR(30) CHECK(ergebnis='Sieg' OR ergebnis='Niederlage' OR ergebnis='Unentschieden') NOT NULL
 );
ALTER TABLE Spiel ADD CONSTRAINT PK_Spiel PRIMARY KEY (datum,bezeichnung);



CREATE TABLE Spieler (
 persnr SERIAL NOT NULL,
 position VARCHAR(50) NOT NULL,
 gehalt DECIMAL(10,2) NOT NULL,
 von DATE NOT NULL,
 bis DATE NOT NULL
 );
ALTER TABLE Spieler ADD CONSTRAINT PK_Spieler PRIMARY KEY (persnr);



CREATE TABLE spielt (
 datum DATE NOT NULL,
 persnr SERIAL NOT NULL,
 mannschaft VARCHAR(50) NOT NULL,
 dauer INT CHECK(dauer>0 AND dauer<=90) NOT NULL
 );
ALTER TABLE spielt ADD CONSTRAINT PK_spielt PRIMARY KEY (datum,persnr,mannschaft);



CREATE TABLE Standort (
 sid SERIAL NOT NULL,
 land VARCHAR(30) NOT NULL,
 ort VARCHAR(60) NOT NULL,
 plz INT NOT NULL
 );
ALTER TABLE Standort ADD CONSTRAINT PK_Standort PRIMARY KEY (sid);


CREATE TABLE Trainer (
 persnr SERIAL NOT NULL,
 gehalt DECIMAL(10,2) NOT NULL,
 von DATE NOT NULL,
 bis DATE NOT NULL,
 mannschaft VARCHAR(50) NOT NULL
 );
ALTER TABLE Trainer ADD CONSTRAINT PK_Trainer PRIMARY KEY (persnr);


CREATE TABLE Angestellter (
 persnr SERIAL NOT NULL,
 gehalt DECIMAL(10,2) NOT NULL,
 ueberstunden INT NOT NULL,
 e_mail VARCHAR(70) NOT NULL
 );
ALTER TABLE Angestellter ADD CONSTRAINT PK_Angestellter PRIMARY KEY (persnr);



CREATE TABLE gehoert_zu (
 nummer INT CHECK(nummer >= 1 AND nummer <= 99)NOT NULL,
 bezeichnung VARCHAR(50) NOT NULL,
 persnr SERIAL NOT NULL, 
 UNIQUE(bezeichnung, persnr)
);
ALTER TABLE gehoert_zu ADD CONSTRAINT PK_gehoert_zu PRIMARY KEY (nummer,bezeichnung);


CREATE TABLE Mitglied (
 persnr SERIAL NOT NULL,
 beitrag DECIMAL(10,2) NOT NULL
 );
ALTER TABLE Mitglied ADD CONSTRAINT PK_Mitglied PRIMARY KEY (persnr);



CREATE TABLE Fanclub (
 name VARCHAR(100) NOT NULL,
 sid SERIAL NOT NULL,
 gegruendet DATE NOT NULL,
 obmann SERIAL NOT NULL UNIQUE
);
ALTER TABLE Fanclub ADD CONSTRAINT PK_Fanclub PRIMARY KEY (name,sid);



CREATE TABLE betreut (
 persnr SERIAL NOT NULL,
 name VARCHAR(100) NOT NULL,
 sid SERIAL NOT NULL,
 anfang DATE NOT NULL,
 ende DATE NOT NULL
);
 ALTER TABLE betreut ADD CONSTRAINT PK_betreut PRIMARY KEY (persnr,name,sid);
 
 
ALTER TABLE Mannschaft ADD CONSTRAINT FK_Mannschaft_1 FOREIGN KEY (cheftrainer) REFERENCES Trainer (persnr) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE Mannschaft ADD CONSTRAINT FK_Mannschaft_2 FOREIGN KEY (assistenztrainer) REFERENCES Trainer (persnr) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE Mannschaft ADD CONSTRAINT FK_Mannschaft_3 FOREIGN KEY (kapitaen) REFERENCES Spieler (persnr);
ALTER TABLE Spiel ADD CONSTRAINT FK_Spiel_0 FOREIGN KEY (bezeichnung) REFERENCES Mannschaft (bezeichnung);
ALTER TABLE Spieler ADD CONSTRAINT FK_Spieler_0 FOREIGN KEY (persnr) REFERENCES Person (persnr);
ALTER TABLE spielt ADD CONSTRAINT FK_spielt_0 FOREIGN KEY (datum,mannschaft) REFERENCES Spiel (datum,bezeichnung);
ALTER TABLE spielt ADD CONSTRAINT FK_spielt_1 FOREIGN KEY (persnr) REFERENCES Spieler (persnr);
ALTER TABLE Trainer ADD CONSTRAINT FK_Trainer_0 FOREIGN KEY (persnr) REFERENCES Person (persnr);
ALTER TABLE Trainer ADD CONSTRAINT FK_Trainer_1 FOREIGN KEY (mannschaft) REFERENCES Mannschaft (bezeichnung) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE Angestellter ADD CONSTRAINT FK_Angestellter_0 FOREIGN KEY (persnr) REFERENCES Person (persnr);
ALTER TABLE gehoert_zu ADD CONSTRAINT FK_gehoert_zu_0 FOREIGN KEY (bezeichnung) REFERENCES Mannschaft (bezeichnung);
ALTER TABLE gehoert_zu ADD CONSTRAINT FK_gehoert_zu_1 FOREIGN KEY (persnr) REFERENCES Spieler (persnr);
ALTER TABLE Mitglied ADD CONSTRAINT FK_Mitglied_0 FOREIGN KEY (persnr) REFERENCES Person (persnr);
ALTER TABLE Fanclub ADD CONSTRAINT FK_Fanclub_0 FOREIGN KEY (sid) REFERENCES Standort (sid);
ALTER TABLE Fanclub ADD CONSTRAINT FK_Fanclub_1 FOREIGN KEY (obmann) REFERENCES Mitglied (persnr);
ALTER TABLE betreut ADD CONSTRAINT FK_betreut_0 FOREIGN KEY (persnr) REFERENCES Angestellter (persnr);
ALTER TABLE betreut ADD CONSTRAINT FK_betreut_1 FOREIGN KEY (name,sid) REFERENCES Fanclub (name,sid);
 



