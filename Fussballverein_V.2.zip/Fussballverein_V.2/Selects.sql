--S6.)
CREATE VIEW trainer_view AS SELECT trainer.persnr, person.vname, person.nname, person.geschlecht, person.gebdat, trainer.gehalt, trainer.von, trainer.bis  
FROM trainer INNER JOIN person ON trainer.persnr=person.persnr;

DROP VIEW trainer_view;

--S2.)
SELECT person.nname, person.persnr FROM betreut INNER JOIN person ON betreut.persnr=person.persnr
WHERE CURRENT_DATE BETWEEN betreut.anfang AND betreut.ende
ORDER BY person.nname ASC;

--S3.)
SELECT spielt.mannschaft, spielt.datum, person.vname, person.nname, spielt.dauer 
FROM spielt INNER JOIN person ON spielt.persnr=person.persnr
WHERE (SELECT EXTRACT(YEAR FROM spielt.datum))=2016
ORDER BY spielt.mannschaft ASC;

--S1.)
SELECT * FROM betreut
WHERE persnr!=10006 OR NOT CURRENT_DATE BETWEEN betreut.anfang AND betreut.ende;

--S4.)
SELECT person.vname, person.nname, SUM(spielt.dauer) AS dauer FROM spielt NATURAL JOIN person
WHERE (SELECT EXTRACT(YEAR FROM spielt.datum))=2015
GROUP BY person.vname, person.nname
UNION
SELECT person.vname, person.nname, spielt.dauer AS dauer FROM spielt NATURAL JOIN person
WHERE (SELECT EXTRACT(YEAR FROM spielt.datum)) = 2015 AND spielt.dauer = 0
GROUP BY person.vname, person.nname, spielt.dauer
ORDER BY dauer DESC;

