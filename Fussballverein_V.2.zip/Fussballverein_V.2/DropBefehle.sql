DROP TABLE Mannschaft;

DROP TABLE Person;

DROP TABLE Spiel;

DROP TABLE Spieler;

DROP TABLE spielt;

DROP TABLE Standort;

DROP TABLE Trainer;

DROP TABLE Angestellter;

DROP TABLE gehoert_zu;

DROP TABLE Mitglied;

DROP TABLE Fanclub;

DROP TABLE betreut;
