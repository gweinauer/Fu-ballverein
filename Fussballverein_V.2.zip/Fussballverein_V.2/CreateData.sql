CREATE TABLE Person ( --df: mult=4.9
 persnr SERIAL CHECK (persnr < 100000) NOT NULL , --df: offset=10000 step=2 size=100001
 vname VARCHAR(30) NOT NULL,
 nname VARCHAR(30) NOT NULL,
 gebdat DATE NOT NULL, --df: start=1970-01-01 end=1995-01-01
 geschlecht CHAR(1) CHECK(geschlecht ='M' OR geschlecht ='W' OR geschlecht ='N') NOT NULL, --df: pattern='(M|W|N)'
 CONSTRAINT PK_Person PRIMARY KEY (persnr)
);

CREATE TABLE Angestellter ( 
 persnr SERIAL NOT NULL REFERENCES Person (persnr), --df: offset=10000
 gehalt DECIMAL(10,2) NOT NULL, 
 ueberstunden INT NOT NULL,
 e_mail VARCHAR(70) NOT NULL, 
 CONSTRAINT PK_Angestellter PRIMARY KEY (persnr),
 --CONSTRAINT FK_Angestellter_0 FOREIGN KEY (persnr) REFERENCES Person (persnr)
 );

CREATE TABLE Mitglied (
 persnr SERIAL NOT NULL REFERENCES Person (persnr), --df: offset=30000
 beitrag DECIMAL(10,2) NOT NULL,
 CONSTRAINT PK_Mitglied PRIMARY KEY (persnr),
 --CONSTRAINT FK_Mitglied_0 FOREIGN KEY (persnr) REFERENCES Person (persnr)
 );

 CREATE TABLE Standort ( --df: mult=0.5
 sid SERIAL NOT NULL, --df: sub=serial
 land VARCHAR(30) NOT NULL,
 ort VARCHAR(60) NOT NULL,
 plz INT NOT NULL,
 CONSTRAINT PK_Standort PRIMARY KEY (sid)
 );

 CREATE TABLE Fanclub ( --df: mult=2.0
 name VARCHAR(100) NOT NULL,  
 sid SERIAL NOT NULL REFERENCES Standort (sid),
 gegruendet DATE NOT NULL, --df: start='1950-01-01' end='2016-01-01'
 obmann SERIAL NOT NULL UNIQUE REFERENCES Mitglied (persnr),
 CONSTRAINT PK_Fanclub PRIMARY KEY (name,sid),
 --CONSTRAINT FK_Fanclub_0 FOREIGN KEY (sid) REFERENCES Standort (sid),
 --CONSTRAINT FK_Fanclub_1 FOREIGN KEY (obmann) REFERENCES Mitglied (persnr)
);

CREATE TABLE betreut ( --dif: mult=4.0
 persnr SERIAL NOT NULL REFERENCES Angestellter (persnr),
 name VARCHAR(100) NOT NULL,
 sid SERIAL NOT NULL,
 anfang DATE NOT NULL, --df: start='1990-01-01' end='2005-01-01'
 ende DATE NOT NULL, --df: start='2005-01-01' end='2025-01-01'
 CONSTRAINT PK_betreut PRIMARY KEY (persnr,name,sid),
 --CONSTRAINT FK_betreut_0 FOREIGN KEY (persnr) REFERENCES Angestellter (persnr)
 
);

CREATE TABLE Spieler ( --df: mult=1.7
 persnr SERIAL NOT NULL REFERENCES Person (persnr), --df: offset=34000 
 position VARCHAR(50) NOT NULL,
 gehalt DECIMAL(10,2) NOT NULL,
 von DATE NOT NULL, --df: start='2008-01-01' end='2016-01-01'
 bis DATE NOT NULL, --df: start='2018-01-01' end='2021-01-01'
 CONSTRAINT PK_Spieler PRIMARY KEY (persnr),
 --CONSTRAINT FK_Spieler_0 FOREIGN KEY (persnr) REFERENCES Person (persnr)
 );

CREATE TABLE Mannschaft ( --df: mult=0.1
 bezeichnung VARCHAR(50) NOT NULL,
 klasse VARCHAR(50) NOT NULL,
 naechstes_spiel DATE NOT NULL, --df: start='2016-05-05' end='2017-01-01'
 cheftrainer SERIAL NOT NULL UNIQUE, --df: offset=30000 step=2 size=2001
 assistenztrainer SERIAL NOT NULL UNIQUE, --df: offset=32000 step=2 size=2001
 kapitaen SERIAL NOT NULL UNIQUE REFERENCES Spieler (persnr),

CONSTRAINT PK_Mannschaft PRIMARY KEY (bezeichnung),
--CONSTRAINT FK_Mannschaft_3 FOREIGN KEY (kapitaen) REFERENCES Spieler (persnr)
);

CREATE TABLE Trainer ( --df: mult=0.2
 persnr SERIAL NOT NULL REFERENCES Person (persnr), --df: offset=30000
 gehalt DECIMAL(10,2) NOT NULL,
 von DATE NOT NULL, --df: start='2000-01-04' end='2016-01-01'
 bis DATE NOT NULL, --df: start='2016-01-01' end='2022-01-01'
 mannschaft VARCHAR(50) NOT NULL REFERENCES Mannschaft (bezeichnung) DEFERRABLE INITIALLY DEFERRED,
 CONSTRAINT PK_Trainer PRIMARY KEY (persnr),
 --CONSTRAINT FK_Trainer_0 FOREIGN KEY (persnr) REFERENCES Person (persnr)
 );
 
ALTER TABLE Mannschaft ADD CONSTRAINT FK_Mannschaft_1 FOREIGN KEY (cheftrainer) REFERENCES Trainer (persnr) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE Mannschaft ADD CONSTRAINT FK_Mannschaft_2 FOREIGN KEY (assistenztrainer) REFERENCES Trainer (persnr) DEFERRABLE INITIALLY DEFERRED;


CREATE TABLE gehoert_zu ( --df: mult=8
 nummer INT CHECK(nummer >= 1 AND nummer <= 99)NOT NULL, --df: sub=uniform offset=1 size=99
 bezeichnung VARCHAR(50) NOT NULL REFERENCES Mannschaft (bezeichnung),
 persnr SERIAL NOT NULL REFERENCES Spieler (persnr), --df: offset=34000 
 UNIQUE(bezeichnung, persnr),
 CONSTRAINT PK_gehoert_zu PRIMARY KEY (nummer,bezeichnung),
 --CONSTRAINT FK_gehoert_zu_0 FOREIGN KEY (bezeichnung) REFERENCES Mannschaft (bezeichnung),
 --CONSTRAINT FK_gehoert_zu_1 FOREIGN KEY (persnr) REFERENCES Spieler (persnr)
);

CREATE TABLE Spiel ( --df: mult=3
 datum DATE NOT NULL PRIMARY KEY, --df: start='2014-01-01' end='2016-04-01'
 bezeichnung VARCHAR(50) UNIQUE NOT NULL REFERENCES Mannschaft (bezeichnung),
 gegner VARCHAR(50) NOT NULL,
 ergebnis VARCHAR(30) CHECK(ergebnis='Sieg' OR ergebnis='Niederlage' OR ergebnis='Unentschieden') NOT NULL, --df: pattern='(Sieg|Niederlage|Unentschieden)'
 --PRIMARY KEY (datum,bezeichnung)
 --CONSTRAINT FK_Spiel_0 FOREIGN KEY (bezeichnung) REFERENCES Mannschaft (bezeichnung)
 );


CREATE TABLE spielt ( --df: mult=5
 datum DATE NOT NULL REFERENCES Spiel (datum),
 persnr SERIAL NOT NULL REFERENCES Spieler (persnr), --fd: offset=34000
 mannschaft VARCHAR(50) NOT NULL REFERENCES Spiel (bezeichnung),
 dauer INT CHECK(dauer>0 AND dauer<=90) NOT NULL, --df: sub=uniform offset=1 size=90
 CONSTRAINT PK_spielt PRIMARY KEY (datum,persnr,mannschaft)
 --CONSTRAINT FK_spielt_0 FOREIGN KEY (datum,mannschaft) REFERENCES Spiel (datum,bezeichnung),
 --CONSTRAINT FK_spielt_1 FOREIGN KEY (persnr) REFERENCES Spieler (persnr)
 );

 
 